function mostra(){
        if(document.getElementById('mostraLigue').style.display == 'inline-block'){
            document.getElementById('mostraLigue').style.display = 'none';
        }else{
            document.getElementById('mostraLigue').style.display = 'inline-block';
        }
    }