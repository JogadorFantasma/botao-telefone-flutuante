<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
<link rel="stylesheet" href="flutuante/flutuante.css" />
<script src="flutuante/flutuante.js"></script>

<div>
        <a href="https://api.whatsapp.com/send?phone=5561999999999" target="_blank">
            <img class="whatsapp" src="flutuante/whatsapp_button.png" width="57" />
        </a>
    </div>
   

    <div class="fixed-action-btn click-to-toggle ">
        <div class="hidden fixed-action-btn1" id="mostraLigue">
            <a href="tel:61-5555-5555" class="btn-floating1 btn-info">
                    <!-- <img  src="images/telephone1.png" width="300" /> -->
                    <div class="telefone"><i class="fa fa-phone"></i>(61)5555-5555<span>Ligue Agora</span></div>
                </a>
        </div>
        <a href="javascript:;" onclick="mostra()"  class="btn-floating btn-large btn-primary">
            <i class="fa fa-phone"></i>
        </a>
    </div>
     
   
